=== SALEKIM Pré-projeto ===
Stable tag: 1.4.0
License: GPLv2 or later

Troca o bloco "Método VIDA" do Portfólio e da página Programas pelo "Pré-projeto", com texto novo.
Funciona junto com o plugin SALEKIM Site. Desativar este plugin traz o bloco antigo de volta.
Na página Sobre, a chamada final vira o título "Conheça nossos programas", com link para as ofertas do Portfólio, sem os botões.
No Portfólio, acrescenta o bloco "Programa Vida após a aposentadoria", no formato da Formação, com "Saiba mais" levando à página de vendas em /vida-apos-aposentadoria/.
